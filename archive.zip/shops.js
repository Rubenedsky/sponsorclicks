
var shops = [];

shops.push({
    id: 12,
    name: "bol.com",
    domain: "bol.com"
});
shops.push({
    id: 1872,
    name: "Fonq.nl",
    domain: "fonq.nl"
});
shops.push({
    id: 85,
    name: "Expedia",
    domain: "expedia.nl"
});
shops.push({
    id: 125,
    name: "Hotels.com",
    domain: "hotels.com"
});
shops.push({
    id: 15,
    name: "Booking.com",
    domain: "booking.com"
});
shops.push({
    id: 2399,
    name: "Vliegtarieven.nl",
    domain: "vliegtarieven.nl"
});
shops.push({
    id: 56,
    name: "Zalando",
    domain: "zalando.nl"
});
shops.push({
    id: 4,
    name: "Thuisbezorgd.nl",
    domain: "thuisbezorgd.nl"
});
shops.push({
    id: 53,
    name: "Wehkamp",
    domain: "wehkamp.nl"
});
shops.push({
    id: 2317,
    name: "Couverts",
    domain: "couverts.nl"
});
shops.push({
    id: 110,
    name: "HEMA",
    domain: "hema.nl"
});
shops.push({
    id: 146,
    name: "Neckermann",
    domain: "neckermann.nl"
});
shops.push({
    id: 2331,
    name: "Traveltroef.nl",
    domain: "traveltroef.nl"
});
shops.push({
    id: 2287,
    name: "Wellnessbon.nl",
    domain: "wellnessbon.nl"
});
shops.push({
    id: 2307,
    name: "Zelfstroom",
    domain: "zelfstroom.nl"
});
shops.push({
    id: 118,
    name: "V%26D",
    domain: "vd.nl"
});
shops.push({
    id: 104,
    name: "Aktiesport.nl",
    domain: "aktiesport.nl"
});
shops.push({
    id: 2092,
    name: "Bart+Smit",
    domain: "bartsmit.com"
});
shops.push({
    id: 2146,
    name: "Blokker",
    domain: "blokker.nl"
});
shops.push({
    id: 1824,
    name: "C%26A",
    domain: "c-and-a.com"
});
shops.push({
    id: 2298,
    name: "Drinkzz",
    domain: "drinkzz.nl"
});
shops.push({
    id: 2258,
    name: "FitForMe",
    domain: "fitforme.nl"
});
shops.push({
    id: 113,
    name: "Hunkem%C3%B6ller",
    domain: "hunkemoller.nl"
});
shops.push({
    id: 2049,
    name: "IkenIk",
    domain: "ikenik.nl"
});
shops.push({
    id: 324,
    name: "kleertjes.com",
    domain: "kleertjes.com"
});
shops.push({
    id: 2148,
    name: "KLM",
    domain: "klm.com"
});
shops.push({
    id: 37,
    name: "OTTO",
    domain: "otto.nl"
});
shops.push({
    id: 114,
    name: "Plutosport",
    domain: "plutosport.nl"
});
shops.push({
    id: 2333,
    name: "Samsung",
    domain: "samsung.com"
});
shops.push({
    id: 2300,
    name: "Slaapdeals.nl",
    domain: "slaapdeals.nl"
});
shops.push({
    id: 2281,
    name: "Staples",
    domain: "staples.nl"
});
shops.push({
    id: 66,
    name: "Vodafone",
    domain: "vodafone.nl"
});
shops.push({
    id: 2250,
    name: "VT+Wonen",
    domain: "vtwonen.nl"
});
shops.push({
    id: 2205,
    name: "Wordpressking.nl",
    domain: "wordpressking.nl"
});
shops.push({
    id: 152,
    name: "Amazing+Kids",
    domain: "amazingkids.n"
});
shops.push({
    id: 2304,
    name: "Avance+Shoes",
    domain: "avanceshoes.com"
});
shops.push({
    id: 2248,
    name: "Beachprincess",
    domain: "beachprincess.nl"
});
shops.push({
    id: 2284,
    name: "Bestecanvas.nl",
    domain: "bestecanvas.nl"
});
shops.push({
    id: 2357,
    name: "BitesWeLove",
    domain: "biteswelove.nl"
});
shops.push({
    id: 14,
    name: "BonPrix",
    domain: "bonprix.nl"
});
shops.push({
    id: 61,
    name: "Coolblue",
    domain: "coolblue.nl"
});
shops.push({
    id: 1,
    name: "Dinnersite.nl",
    domain: "dinnersite.nl"
});
shops.push({
    id: 2330,
    name: "Domino%27s",
    domain: "dominos.nl"
});
shops.push({
    id: 2354,
    name: "EBBM",
    domain: "ebbm.nl"
});
shops.push({
    id: 91,
    name: "Essent",
    domain: "essent.nl"
});
shops.push({
    id: 719,
    name: "Fashion+for+Home",
    domain: "fashionforhome.nl"
});
shops.push({
    id: 2210,
    name: "Fitness-Geest",
    domain: "fitness-geest.nl"
});
shops.push({
    id: 2194,
    name: "Geld+Gorilla+Geheimen",
    domain: "geldgorilla.nl"
});
shops.push({
    id: 2385,
    name: "Greetz",
    domain: "greetz.nl"
});
shops.push({
    id: 2269,
    name: "Hewlett-Packard+%28HP%29",
    domain: "hp.com"
});
shops.push({
    id: 2165,
    name: "Home24",
    domain: "home24.nl"
});
shops.push({
    id: 2253,
    name: "HotelsClick.com",
    domain: "hotelsclick.com"
});
shops.push({
    id: 2177,
    name: "Kettlebell+Workout",
    domain: "kettlebellworkouts.nl"
});
shops.push({
    id: 2147,
    name: "Leen+Bakker",
    domain: "leenbakker.nl"
});
shops.push({
    id: 2251,
    name: "Lensstore",
    domain: "lensstore.nl"
});
shops.push({
    id: 2199,
    name: "Marktplaats+Geheimen",
    domain: "marktplaatsgeheimen.nl"
});
shops.push({
    id: 2202,
    name: "Netspecialist.nl",
    domain: "netspecialist.nl"
});
shops.push({
    id: 208,
    name: "Nuon",
    domain: "nuon.nl"
});
shops.push({
    id: 2221,
    name: "PianoPro",
    domain: "pianopro.nl"
});
shops.push({
    id: 2285,
    name: "Qurrent",
    domain: "qurrent.nl"
});
shops.push({
    id: 1931,
    name: "Redcoon",
    domain: "redcoon.nl"
});
shops.push({
    id: 2189,
    name: "Slimsticks",
    domain: "slimsticks.nl"
});
shops.push({
    id: 2296,
    name: "SpaOnline",
    domain: "spaonline.com"
});
shops.push({
    id: 2160,
    name: "Superdry",
    domain: "superdry.nl"
});
shops.push({
    id: 2235,
    name: "Typhone",
    domain: "typhone.nl"
});
shops.push({
    id: 2228,
    name: "UnitedConsumers",
    domain: "unitedconsumers.com"
});
shops.push({
    id: 2448,
    name: "Venere+Hotels",
    domain: "venere.com"
});
shops.push({
    id: 54,
    name: "Wehkamp",
    domain: "wehkamp.nl"
});
shops.push({
    id: 2241,
    name: "Witgoedhuis",
    domain: "witgoedhuis.nl"
});
shops.push({
    id: 2247,
    name: "Zonnebrillen.com",
    domain: "zonnebrillen.com"
});
shops.push({
    id: 2321,
    name: "Douglas",
    domain: "douglas.nl"
});
shops.push({
    id: 2261,
    name: "Afvallen+met+Nederland",
    domain: "afvallenmetnederland.nl"
});
shops.push({
    id: 2313,
    name: "Albelli",
    domain: "albelli.nl"
});
shops.push({
    id: 2320,
    name: "AliExpress",
    domain: "aliexpress.com"
});
shops.push({
    id: 2290,
    name: "Bestelkado.nl",
    domain: "bestelkado.nl"
});
shops.push({
    id: 2343,
    name: "Beter+Bed",
    domain: "beterbed.nl"
});
shops.push({
    id: 2263,
    name: "Biedbazaar",
    domain: "biedbazaar.nl"
});
shops.push({
    id: 2273,
    name: "Bodystore.nl",
    domain: "bodystore.nl"
});
shops.push({
    id: 2299,
    name: "Bristol",
    domain: "bristol.nl"
});
shops.push({
    id: 2245,
    name: "Cadeau.nl",
    domain: "cadeau.nl"
});
shops.push({
    id: 2254,
    name: "Chalet.nu",
    domain: "chalet.nu"
});
shops.push({
    id: 2324,
    name: "Coffeeduck",
    domain: "coffeeduck.com"
});
shops.push({
    id: 1797,
    name: "Conrad",
    domain: "conrad.nl"
});
shops.push({
    id: 2365,
    name: "Coolcat",
    domain: "coolcat.nl"
});
shops.push({
    id: 2358,
    name: "DesignSkins",
    domain: "designskins.nl"
});
shops.push({
    id: 116,
    name: "Dolcis",
    domain: "dolcis.nl"
});
shops.push({
    id: 2226,
    name: "Elektriciteitinstallatie",
    domain: "elektriciteitinstallatie.nl"
});
shops.push({
    id: 2066,
    name: "Expresso",
    domain: "expresso.nl"
});
shops.push({
    id: 2265,
    name: "Fiber",
    domain: "fiber.nl"
});
shops.push({
    id: 2349,
    name: "FoodWeLove",
    domain: "foodwelove.nl"
});
shops.push({
    id: 2259,
    name: "Frederiques+Choice",
    domain: "frederiqueschoice.com"
});
shops.push({
    id: 2219,
    name: "Freds+Bouwtekeningen",
    domain: "fredsbouwtekeningen.nl"
});
shops.push({
    id: 2291,
    name: "Gadgethouse.nl",
    domain: "gadgethouse.nl"
});
shops.push({
    id: 2198,
    name: "Geld+verdienen+met+opties",
    domain: "beleggen.com"
});
shops.push({
    id: 2286,
    name: "Hoesjescases.nl",
    domain: "hoesjescases.nl"
});
shops.push({
    id: 2218,
    name: "Hotels.nl",
    domain: "hotels.nl"
});
shops.push({
    id: 2045,
    name: "Intertoys",
    domain: "intertoys.nl"
});
shops.push({
    id: 2361,
    name: "iParts4u.nl",
    domain: "iparts4u.nl"
});
shops.push({
    id: 2308,
    name: "Leesmap",
    domain: "leesmap.nl"
});
shops.push({
    id: 2053,
    name: "Light+In+The+Box+",
    domain: "lightinthebox.com"
});
shops.push({
    id: 2404,
    name: "Manfield",
    domain: "manfield.com"
});
shops.push({
    id: 2392,
    name: "Men+at+Work",
    domain: "menatwork.nl"
});
shops.push({
    id: 2381,
    name: "MissEtam",
    domain: "missetam.nl"
});
shops.push({
    id: 2216,
    name: "Mobiel.nl",
    domain: "mobiel.nl"
});
shops.push({
    id: 2203,
    name: "Netspecialist.nl",
    domain: "netspecialist.nl"
});
shops.push({
    id: 2282,
    name: "NH+-+Hoteles",
    domain: "nh-hotels.nl"
});
shops.push({
    id: 2268,
    name: "Oxxio",
    domain: "oxxio.nl"
});
shops.push({
    id: 2224,
    name: "Photoshop+Basiscursus",
    domain: "http://photoshoponderdeknie.nl/"
});
shops.push({
    id: 2262,
    name: "Sexyshoes",
    domain: "sexyshoes.nl"
});
shops.push({
    id: 2302,
    name: "Shapewear.nl",
    domain: "shapewear.nl"
});
shops.push({
    id: 2163,
    name: "Shoeby",
    domain: "shoeby.nl"
});
shops.push({
    id: 2355,
    name: "Shoepassion",
    domain: "shoepassion.nl"
});
shops.push({
    id: 2436,
    name: "Sneakerbaas",
    domain: "sneakerbaas.com"
});
shops.push({
    id: 2233,
    name: "Spreadshirt",
    domain: "spreadshirt.nl"
});
shops.push({
    id: 2209,
    name: "Tennis-Geest",
    domain: "tennis-geest.nl"
});
shops.push({
    id: 2266,
    name: "TransIP",
    domain: "transip.nl"
});
shops.push({
    id: 2341,
    name: "Tuinmeubelen.nl",
    domain: "tuinmeubelen.nl"
});
shops.push({
    id: 2264,
    name: "Uitverkoopnederland.nl",
    domain: "uitverkoopnederland.nl"
});
shops.push({
    id: 2328,
    name: "UnderArmour",
    domain: "underarmour.nl"
});
shops.push({
    id: 48,
    name: "Viking",
    domain: "vikingdirect.nl"
});
shops.push({
    id: 2207,
    name: "Voetbal-Geest",
    domain: "voetbal-geest.nl"
});
shops.push({
    id: 2027,
    name: "Webprint.nl",
    domain: "webprint.nl"
});
shops.push({
    id: 2371,
    name: "10topwijnen+",
    domain: "10topwijnen.nl"
});
shops.push({
    id: 46,
    name: "123tijdschrift.nl",
    domain: "123tijdschrift.nl"
});
shops.push({
    id: 149,
    name: "Avantisport",
    domain: "avantisport.nl"
});
shops.push({
    id: 2051,
    name: "Bax",
    domain: "bax-shop.nl"
});
shops.push({
    id: 2315,
    name: "Bundles",
    domain: "bundles.nl"
});
shops.push({
    id: 1869,
    name: "Centralpoint",
    domain: "centralpoint.nl"
});
shops.push({
    id: 2196,
    name: "De+Rijke+Stinkerd",
    domain: "derijkestinkerd.net"
});
shops.push({
    id: 1822,
    name: "Drogisterij.net",
    domain: "drogisterij.net"
});
shops.push({
    id: 2191,
    name: "Electrabel",
    domain: "electrabel.nl"
});
shops.push({
    id: 2383,
    name: "Fotogeprint.nl",
    domain: "fotogeprint.nl"
});
shops.push({
    id: 2187,
    name: "Fun+%26+Feestwinkel",
    domain: "funenfeestwinkel.nl"
});
shops.push({
    id: 2179,
    name: "Gezonde+Groene+Smoothie",
    domain: "stayhealthy.nl"
});
shops.push({
    id: 2393,
    name: "Gilian+Originals",
    domain: "gilianoriginals.nl"
});
shops.push({
    id: 2335,
    name: "Goosecraft",
    domain: "goosecraft.nl"
});
shops.push({
    id: 2243,
    name: "Gorillasports",
    domain: "gorillasports.nl"
});
shops.push({
    id: 2439,
    name: "GSMwijzer.nl",
    domain: "gsmwijzer.nl"
});
shops.push({
    id: 2208,
    name: "Hardloop-Geest",
    domain: "hardloop-geest.nl"
});
shops.push({
    id: 2346,
    name: "Hostelsclub.com",
    domain: "hostelsclub.com"
});
shops.push({
    id: 147,
    name: "iBood",
    domain: "ibood.com"
});
shops.push({
    id: 30,
    name: "ICI+PARIS+XL",
    domain: "iciparisxl.nl"
});
shops.push({
    id: 2126,
    name: "Inktweb.nl",
    domain: "inktweb.nl"
});
shops.push({
    id: 160,
    name: "Invito",
    domain: "invito.com"
});
shops.push({
    id: 2350,
    name: "Jouwsportzaak.nl",
    domain: "jouwsportzaak.nl"
});
shops.push({
    id: 2502,
    name: "Kerst-feestwinkel.nl",
    domain: "kerst-feestwinkel.nl"
});
shops.push({
    id: 2374,
    name: "Kleinflesjewijn",
    domain: "kleinflesjewijn.nl"
});
shops.push({
    id: 2429,
    name: "Koeka",
    domain: "koeka.com"
});
shops.push({
    id: 2033,
    name: "Lensway.nl",
    domain: "lensway.nl"
});
shops.push({
    id: 2345,
    name: "Magix.com",
    domain: "magix.com"
});
shops.push({
    id: 2329,
    name: "Marks+%26+Spencer",
    domain: "marksandspencer.eu"
});
shops.push({
    id: 2114,
    name: "MedionShop",
    domain: "medion.com"
});
shops.push({
    id: 1950,
    name: "MegaGadgets.nl",
    domain: "megagadgets.nl"
});
shops.push({
    id: 2180,
    name: "Mentale+Dieet+Plan",
    domain: "mentaledieetplan.nl"
});
shops.push({
    id: 2356,
    name: "Mijnpin.nl",
    domain: "mijnpin.nl"
});
shops.push({
    id: 2337,
    name: "ModeMusthaves",
    domain: "modemusthaves.com"
});
shops.push({
    id: 2201,
    name: "NewStart+eCursus+Vind+Je+Ideale+Baan",
    domain: "newstart.nl"
});
shops.push({
    id: 2142,
    name: "Nudeal",
    domain: "nudeal.nl"
});
shops.push({
    id: 2275,
    name: "PerfectBody.nl",
    domain: "perfectbody.nl"
});
shops.push({
    id: 2295,
    name: "Perfume%27s+club",
    domain: "perfumesclub.nl"
});
shops.push({
    id: 2362,
    name: "Photobox",
    domain: "photobox.nl"
});
shops.push({
    id: 2136,
    name: "Planet+Sports",
    domain: "planet-sports.com"
});
shops.push({
    id: 2359,
    name: "Plasma-discounter",
    domain: "plasma-discounter.nl"
});
shops.push({
    id: 2234,
    name: "Posters.nl",
    domain: "posters.nl"
});
shops.push({
    id: 2352,
    name: "PosterXXL",
    domain: "posterxxl.nl"
});
shops.push({
    id: 2348,
    name: "PriceRebel.nl",
    domain: "pricerebel.nl"
});
shops.push({
    id: 2217,
    name: "Ritel",
    domain: "ritel.nl"
});
shops.push({
    id: 2410,
    name: "Roberto+Romero",
    domain: "roberto-romero.com"
});
shops.push({
    id: 2405,
    name: "Scapino",
    domain: "scapino.nl"
});
shops.push({
    id: 63,
    name: "Score",
    domain: "score.nl"
});
shops.push({
    id: 2342,
    name: "Shoelabelz",
    domain: "shoelabelz.nl"
});
shops.push({
    id: 2360,
    name: "Sport44.com",
    domain: "sport44.com"
});
shops.push({
    id: 2390,
    name: "Sporthuis.nl",
    domain: "sporthuis.nl"
});
shops.push({
    id: 2271,
    name: "Sportvoedingwebshop.com",
    domain: "sportvoedingwebshop.com"
});
shops.push({
    id: 2195,
    name: "Startpakket+Thuiswerk",
    domain: "startpakket-thuiswerk.nl"
});
shops.push({
    id: 2318,
    name: "Studentmobiel",
    domain: "studentmobiel.nl"
});
shops.push({
    id: 2312,
    name: "Stylepit",
    domain: "stylepit.nl"
});
shops.push({
    id: 2292,
    name: "Supersaver.nl",
    domain: "supersaver.nl"
});
shops.push({
    id: 122,
    name: "T-Mobile+Online",
    domain: "t-mobile.nl"
});
shops.push({
    id: 169,
    name: "Tonershop.nl",
    domain: "tonershop.nl"
});
shops.push({
    id: 108,
    name: "vanHaren",
    domain: "vanharen.nl"
});
shops.push({
    id: 2380,
    name: "Vivara",
    domain: "vivara.nl"
});
shops.push({
    id: 50,
    name: "Voetbaldirect.nl",
    domain: "voetbaldirect.nl"
});
shops.push({
    id: 2387,
    name: "Voetbalhuis.nl",
    domain: "voetbalhuis.nl"
});
shops.push({
    id: 2432,
    name: "Voetbalshirtjeswinkel.nl",
    domain: "voetbalshirtjeswinkel.nl"
});
shops.push({
    id: 2391,
    name: "VOGA",
    domain: "voga.com"
});
shops.push({
    id: 2396,
    name: "YourSurprise.nl",
    domain: "yoursurprise.nl"
});
shops.push({
    id: 1830,
    name: "Sneltoner.nl",
    domain: "sneltoner.nl"
});
shops.push({
    id: 2117,
    name: "AVTrader",
    domain: "avtrader.nl"
});
shops.push({
    id: 2311,
    name: "Befit2day",
    domain: "befit2day.nl"
});
shops.push({
    id: 2278,
    name: "Betersport.nl",
    domain: "betersport.nl"
});
shops.push({
    id: 2377,
    name: "Bloembollenkopen.nl",
    domain: "bloembollenkopen.nl"
});
shops.push({
    id: 2454,
    name: "BoeketCadeau.nl",
    domain: "boeketcadeau.nl"
});
shops.push({
    id: 2475,
    name: "Bongo",
    domain: "bongo.nl"
});
shops.push({
    id: 2370,
    name: "Brievenbusbloemen",
    domain: "brievenbusbloemen.nl"
});
shops.push({
    id: 2400,
    name: "Cook%26Co",
    domain: "cookandco.nl"
});
shops.push({
    id: 2398,
    name: "Damestassenenzo.nl",
    domain: "damestassenenzo.nl"
});
shops.push({
    id: 2071,
    name: "Delta+Loyd",
    domain: "deltalloyd.nl"
});
shops.push({
    id: 2325,
    name: "DriversOnly",
    domain: "driversonly.nl"
});
shops.push({
    id: 166,
    name: "Drukwerkdiscounter.com",
    domain: "drukwerkdiscounter.com"
});
shops.push({
    id: 2116,
    name: "Dutch+Designers+Outlet",
    domain: "dutchdesignersoutlet.com"
});
shops.push({
    id: 171,
    name: "ebookers.nl",
    domain: "ebookers.nl"
});
shops.push({
    id: 67,
    name: "Energiedirect.nl",
    domain: "energiedirect.nl"
});
shops.push({
    id: 72,
    name: "Euroflorist",
    domain: "euroflorist.nl"
});
shops.push({
    id: 2339,
    name: "Expert",
    domain: "expert.nl"
});
shops.push({
    id: 2497,
    name: "Fietsweb.nl",
    domain: "fietsweb.nl"
});
shops.push({
    id: 99,
    name: "Gaastra",
    domain: "gaastraproshop.com"
});
shops.push({
    id: 2395,
    name: "Gezonder.nu",
    domain: "gezonder.nu"
});
shops.push({
    id: 2220,
    name: "Gitaarles",
    domain: "gitaarles.nl"
});
shops.push({
    id: 2120,
    name: "Happy+Hour+Table",
    domain: "happyhourtable.com"
});
shops.push({
    id: 2427,
    name: "Happybee",
    domain: "happybee.nl"
});
shops.push({
    id: 2334,
    name: "HelloFresh",
    domain: "hellofresh.nl"
});
shops.push({
    id: 134,
    name: "Hogenboom+Vakantieparken",
    domain: "vakantiegevoel.nl"
});
shops.push({
    id: 2435,
    name: "Hotel+Okura+Amsterdam",
    domain: "okura.nl"
});
shops.push({
    id: 2382,
    name: "Huisdierplein.nl",
    domain: "huisdierplein.nl"
});
shops.push({
    id: 2309,
    name: "iChica",
    domain: "ichica.nl"
});
shops.push({
    id: 1954,
    name: "Inkclub.com",
    domain: "inkclub.com"
});
shops.push({
    id: 2437,
    name: "Interieurvannu.nl",
    domain: "interieurvannu.nl"
});
shops.push({
    id: 2403,
    name: "Intreza",
    domain: "intreza.nl"
});
shops.push({
    id: 2118,
    name: "Kekwomen",
    domain: "kekwomen.nl"
});
shops.push({
    id: 2378,
    name: "Keukenaccessoiresshop.nl",
    domain: "keukenaccessoiresshop.nl"
});
shops.push({
    id: 2332,
    name: "LOI",
    domain: "loi.nl"
});
shops.push({
    id: 2407,
    name: "Loungeset.nl",
    domain: "loungeset.nl"
});
shops.push({
    id: 2057,
    name: "Madeleine+Fashion",
    domain: "madeleine-fashion.nl"
});
shops.push({
    id: 2379,
    name: "Maxbedden.nl",
    domain: "maxbedden.nl"
});
shops.push({
    id: 1996,
    name: "Modern.nl",
    domain: "modern.nl"
});
shops.push({
    id: 2055,
    name: "MS+Mode",
    domain: "msmode.nl"
});
shops.push({
    id: 2215,
    name: "Office+Deals",
    domain: "office-deals.nl"
});
shops.push({
    id: 2417,
    name: "Online.nl",
    domain: "online.nl"
});
shops.push({
    id: 2184,
    name: "Paleo",
    domain: "paleo.nl"
});
shops.push({
    id: 2388,
    name: "Personalgifts.nl",
    domain: "personalgifts.nl"
});
shops.push({
    id: 2411,
    name: "Peterhahn.nl",
    domain: "peterhahn.nl"
});
shops.push({
    id: 2406,
    name: "Pro-shoes.nl",
    domain: "pro-shoes.nl"
});
shops.push({
    id: 2430,
    name: "Shoehoo",
    domain: "shoehoo.nl"
});
shops.push({
    id: 71,
    name: "Simpel",
    domain: "simpel.nl"
});
shops.push({
    id: 2327,
    name: "SmartBuyGlasses",
    domain: "smartbuyglasses.nl"
});
shops.push({
    id: 2200,
    name: "soChicken+eCursus+Uitstelgedrag",
    domain: "sochicken.nl"
});
shops.push({
    id: 2419,
    name: "Studieplan",
    domain: "studieplan.nl"
});
shops.push({
    id: 78,
    name: "Tele2",
    domain: "tele2.nl"
});
shops.push({
    id: 2322,
    name: "Theorie-Examens.nl",
    domain: "theorie-examens.nl"
});
shops.push({
    id: 2119,
    name: "Travel+24+Deals",
    domain: "travel24-deals.nl"
});
shops.push({
    id: 2440,
    name: "Vamos-schoenen.nl",
    domain: "vamos-schoenen.nl"
});
shops.push({
    id: 2204,
    name: "Vertaalwerk.net",
    domain: "vertaalwerk.net"
});
shops.push({
    id: 2170,
    name: "VITADIS",
    domain: "vitadis.nl"
});
shops.push({
    id: 2211,
    name: "Wandel-Geest",
    domain: "wandel-geest.nl"
});
shops.push({
    id: 2310,
    name: "Watch2day",
    domain: "watch2day.nl"
});
shops.push({
    id: 2402,
    name: "Xenos",
    domain: "xenos.nl"
});
shops.push({
    id: 2192,
    name: "Youfone",
    domain: "youfone.nl"
});
shops.push({
    id: 9,
    name: "Ben",
    domain: "ben.nl"
});
shops.push({
    id: 60,
    name: "Bj%C3%B6rn+Borg",
    domain: "bjornborg.com"
});
shops.push({
    id: 2153,
    name: "Bootsandwoods",
    domain: "bootsandwoods.nl"
});
shops.push({
    id: 2079,
    name: "BuyYourWine.com",
    domain: "buyyourwine.com"
});
shops.push({
    id: 2080,
    name: "Bythegrape.nl",
    domain: "bythegrape.nl"
});
shops.push({
    id: 117,
    name: "Canal+Digitaal",
    domain: "canaldigitaal.nl"
});
shops.push({
    id: 18,
    name: "Center+Parcs",
    domain: "centerparcs.nl"
});
shops.push({
    id: 145,
    name: "De+Tuinen",
    domain: "detuinen.nl"
});
shops.push({
    id: 24,
    name: "Dress-for-less.nl",
    domain: "dress-for-less.nl"
});
shops.push({
    id: 92,
    name: "E.ON",
    domain: "eon.nl"
});
shops.push({
    id: 130,
    name: "Groupdeal.nl",
    domain: "groupdeal.nl"
});
shops.push({
    id: 80,
    name: "Hans+Anders",
    domain: "hansanders.nl"
});
shops.push({
    id: 87,
    name: "Hificorner.nl",
    domain: "hificorner.nl"
});
shops.push({
    id: 34,
    name: "KPN",
    domain: "kpn.com"
});
shops.push({
    id: 1947,
    name: "Medpets.nl",
    domain: "medpets.nl"
});
shops.push({
    id: 2073,
    name: "Paradigit",
    domain: "paradigit.nl"
});
shops.push({
    id: 77,
    name: "Phonehouse",
    domain: "phonehouse.nl"
});
shops.push({
    id: 119,
    name: "Simyo",
    domain: "simyo.nl"
});
shops.push({
    id: 1925,
    name: "Tonerwinkel.nl",
    domain: "tonerwinkel.nl"
});
shops.push({
    id: 115,
    name: "Toys+R+Us",
    domain: "toysrus.nl"
});
shops.push({
    id: 101,
    name: "Ulla+Popken",
    domain: "ullapopken.nl"
});
shops.push({
    id: 2085,
    name: "Wijnoutlet.nl",
    domain: "wijnoutlet.nl"
});
shops.push({
    id: 2039,
    name: "Zooplus",
    domain: "zooplus.nl"
});
shops.push({
    id: 2167,
    name: "7x7+Afslank+receptenboek",
    domain: "jasperalblas.nl"
});
shops.push({
    id: 320,
    name: "babyhuys",
    domain: "babyhuyswebshop.nl"
});
shops.push({
    id: 321,
    name: "Babywalz",
    domain: "baby-walz.nl"
});
shops.push({
    id: 2089,
    name: "Badjasparadijs",
    domain: "badjasparadijs.nl"
});
shops.push({
    id: 1923,
    name: "Bakker+Hillegom",
    domain: "bakker-hillegom.nl"
});
shops.push({
    id: 2471,
    name: "Banggood.com",
    domain: "banggood.com"
});
shops.push({
    id: 2441,
    name: "Bedden.nl",
    domain: "bedden.nl"
});
shops.push({
    id: 2434,
    name: "Bedrijfsplantraining.nl",
    domain: "bedrijfsplantraining.nl"
});
shops.push({
    id: 1975,
    name: "Bellatio",
    domain: "bellatio.nl"
});
shops.push({
    id: 2426,
    name: "Brandkids",
    domain: "brandkids.nl"
});
shops.push({
    id: 68,
    name: "Brunotti",
    domain: "brunotti.com"
});
shops.push({
    id: 2031,
    name: "Camera.nl",
    domain: "camera.nl"
});
shops.push({
    id: 2161,
    name: "Clarks",
    domain: "clarks.nl"
});
shops.push({
    id: 2486,
    name: "Cosmania",
    domain: "cosmania.nl"
});
shops.push({
    id: 1942,
    name: "Crocs",
    domain: "crocs.nl"
});
shops.push({
    id: 2137,
    name: "Czech+Airlines",
    domain: "nl.csa.cz"
});
shops.push({
    id: 2450,
    name: "Dekoria.nl",
    domain: "dekoria.nl"
});
shops.push({
    id: 2509,
    name: "Demannenvanbrandhof.nl",
    domain: "demannenvanbrandhof.nl"
});
shops.push({
    id: 2451,
    name: "Denimplus",
    domain: "denimplus.nl"
});
shops.push({
    id: 2444,
    name: "DeOnlineDrogist.nl",
    domain: "deonlinedrogist.nl"
});
shops.push({
    id: 2498,
    name: "Directlampen.nl",
    domain: "directlampen.nl"
});
shops.push({
    id: 2443,
    name: "Doublepoint.nl",
    domain: "doublepoint.nl"
});
shops.push({
    id: 2469,
    name: "Douche-Concurrent.nl",
    domain: "douche-concurrent.nl"
});
shops.push({
    id: 2470,
    name: "Dualbrella.nl",
    domain: "dualbrella.nl"
});
shops.push({
    id: 1964,
    name: "Fleurop+Interflora",
    domain: "fleurop.nl"
});
shops.push({
    id: 2030,
    name: "Forzawielerreizen.nl",
    domain: "forzawielerreizen.nl"
});
shops.push({
    id: 2501,
    name: "Fotogeschenk.nl",
    domain: "fotogeschenk.nl"
});
shops.push({
    id: 1747,
    name: "Freshlabelz",
    domain: "freshlabelz.nl"
});
shops.push({
    id: 2135,
    name: "Gaastra",
    domain: "gaastraproshop.com"
});
shops.push({
    id: 106,
    name: "Gameduell",
    domain: "gameduell.nl"
});
shops.push({
    id: 95,
    name: "GoMundo",
    domain: "gomundo.nl"
});
shops.push({
    id: 718,
    name: "Groupactie",
    domain: "groupactie.nl"
});
shops.push({
    id: 2422,
    name: "GSMoplader.nl",
    domain: "gsmoplader.nl"
});
shops.push({
    id: 2485,
    name: "Haarshop",
    domain: "haarshop.nl"
});
shops.push({
    id: 105,
    name: "Heine",
    domain: "heine-shop.nl"
});
shops.push({
    id: 2001,
    name: "Hockeyhuis.nl",
    domain: "hockeyhuis.nl"
});
shops.push({
    id: 27,
    name: "hollandsnieuwe",
    domain: "hollandsnieuwe.nl"
});
shops.push({
    id: 2428,
    name: "Ikenmijnkind.nl",
    domain: "ikenmijnkind.nl"
});
shops.push({
    id: 150,
    name: "Independer.nl",
    domain: "independer.nl"
});
shops.push({
    id: 1924,
    name: "inktpatroonshop.nl",
    domain: "inktpatroonshop.nl"
});
shops.push({
    id: 2131,
    name: "inktpatroonshop.nl",
    domain: "inktpatroonshop.nl"
});
shops.push({
    id: 2467,
    name: "InStyler",
    domain: "instyler.nl"
});
shops.push({
    id: 2438,
    name: "Internet-bikes.com",
    domain: "internet-bikes.com"
});
shops.push({
    id: 2036,
    name: "Jamin",
    domain: "jamin.nl"
});
shops.push({
    id: 2494,
    name: "Jeeigentaart.nl",
    domain: "jeeigentaart.nl"
});
shops.push({
    id: 161,
    name: "Jet2.com",
    domain: "jet2.com"
});
shops.push({
    id: 2415,
    name: "Kaartwereld",
    domain: "kaartwereld.nl"
});
shops.push({
    id: 1957,
    name: "Keukenmarkt.nl",
    domain: "keukenmarkt.nl"
});
shops.push({
    id: 2424,
    name: "Kinderkleding-tekoop.nl",
    domain: "kinderkleding-tekoop.nl"
});
shops.push({
    id: 173,
    name: "Kinderkleding.nl",
    domain: "kinderkleding.nl"
});
shops.push({
    id: 1832,
    name: "Kixx-online.nl",
    domain: "kixx-online.nl"
});
shops.push({
    id: 2479,
    name: "Kluscenter.nl",
    domain: "kluscenter.nl"
});
shops.push({
    id: 326,
    name: "knuffelparadijs",
    domain: "knuffelparadijs.nl"
});
shops.push({
    id: 2457,
    name: "Koffiediscounter.nl",
    domain: "koffiediscounter.nl"
});
shops.push({
    id: 2046,
    name: "Lexa.nl",
    domain: "lexa.nl"
});
shops.push({
    id: 136,
    name: "LOI",
    domain: "loi.nl"
});
shops.push({
    id: 2505,
    name: "LOKS",
    domain: "loks.nl"
});
shops.push({
    id: 2466,
    name: "Magnetron.nl",
    domain: "magnetron.nl"
});
shops.push({
    id: 2490,
    name: "Makeupshoppen",
    domain: "makeupshoppen.nl"
});
shops.push({
    id: 2491,
    name: "Meghoe+Automotive",
    domain: "meghoe-automotive.nl"
});
shops.push({
    id: 2166,
    name: "Mentale+Dieet+Plan",
    domain: "mentaledieetplan.com"
});
shops.push({
    id: 1933,
    name: "Mijndomein.nl",
    domain: "mijndomein.nl"
});
shops.push({
    id: 2260,
    name: "MooiVakanties",
    domain: "mooivakanties.nl"
});
shops.push({
    id: 2510,
    name: "Morpheus-beddengoed.nl",
    domain: "morpheus-beddengoed.nl"
});
shops.push({
    id: 2495,
    name: "Nedgame",
    domain: "nedgame.nl"
});
shops.push({
    id: 2442,
    name: "NeeltjeJans.nl",
    domain: "neeltjejans.nl"
});
shops.push({
    id: 2460,
    name: "Neostrada.nl",
    domain: "neostrada.nl"
});
shops.push({
    id: 96,
    name: "NL+Energie",
    domain: "nle.nl"
});
shops.push({
    id: 140,
    name: "OHRA",
    domain: "ohra.nl"
});
shops.push({
    id: 2425,
    name: "Olliewood",
    domain: "olliewood.nl"
});
shops.push({
    id: 1948,
    name: "Onlinedierenspeciaalzaak.nl",
    domain: "onlinedierenspeciaalzaak.nl"
});
shops.push({
    id: 2487,
    name: "Onlineverf.nl",
    domain: "onlineverf.nl"
});
shops.push({
    id: 1966,
    name: "Oranjediscounter.nl",
    domain: "oranjediscounter.nl"
});
shops.push({
    id: 1949,
    name: "P%26O+Ferries",
    domain: "poferries.com"
});
shops.push({
    id: 2456,
    name: "Paintballstrand.nl",
    domain: "paintballstrand.nl"
});
shops.push({
    id: 75,
    name: "Parship.nl",
    domain: "parship.nl"
});
shops.push({
    id: 2453,
    name: "Pestana",
    domain: "pestana.com"
});
shops.push({
    id: 144,
    name: "Philips",
    domain: "philips.nl"
});
shops.push({
    id: 2394,
    name: "PortemonneeZ.nl",
    domain: "portemonneez.nl"
});
shops.push({
    id: 2412,
    name: "Print-things.nl",
    domain: "print-things.nl"
});
shops.push({
    id: 2473,
    name: "Printvoordeelshop.nl",
    domain: "printvoordeelshop.nl"
});
shops.push({
    id: 2408,
    name: "Prozis",
    domain: "prozis.com"
});
shops.push({
    id: 76,
    name: "Relatieplanet.nl",
    domain: "relatieplanet.nl"
});
shops.push({
    id: 2433,
    name: "Replacedirect.nl",
    domain: "replacedirect.nl"
});
shops.push({
    id: 2484,
    name: "ShopnDrop",
    domain: "shopndrop.nl"
});
shops.push({
    id: 1870,
    name: "SinQel.com",
    domain: "sinqel.com"
});
shops.push({
    id: 2463,
    name: "Sloffen-webshop.nl",
    domain: "sloffen-webshop.nl"
});
shops.push({
    id: 2468,
    name: "Sneeuwkettingen.com",
    domain: "sneeuwkettingen.com"
});
shops.push({
    id: 2492,
    name: "Soccerfanshop.nl",
    domain: "soccerfanshop.nl"
});
shops.push({
    id: 2452,
    name: "Soundmaster-shop.nl",
    domain: "soundmaster-shop.nl"
});
shops.push({
    id: 2488,
    name: "Sovita",
    domain: "sovita.nl"
});
shops.push({
    id: 331,
    name: "speelgoedpostorder",
    domain: "speelgoedpostorder.nl"
});
shops.push({
    id: 2480,
    name: "Stuntwinkel.nl",
    domain: "stuntwinkel.nl"
});
shops.push({
    id: 2038,
    name: "Subsidesports.nl",
    domain: "subsidesports.nl"
});
shops.push({
    id: 121,
    name: "Sunglasses+shop",
    domain: "sunglasses-shop.nl"
});
shops.push({
    id: 88,
    name: "Swarovski",
    domain: "swarovski.com"
});
shops.push({
    id: 2499,
    name: "Taartenwinkel.nl",
    domain: "taartenwinkel.nl"
});
shops.push({
    id: 2445,
    name: "Tassen4jou.nl",
    domain: "tassen4jou.nl"
});
shops.push({
    id: 2369,
    name: "TeeVee.io",
    domain: "teevee.io"
});
shops.push({
    id: 2493,
    name: "Telefoondiscounter.nl",
    domain: "telefoondiscounter.nl"
});
shops.push({
    id: 2340,
    name: "Ticketmaster+NL",
    domain: "ticketmaster.nl"
});
shops.push({
    id: 64,
    name: "Tom+Tailor",
    domain: "tom-tailor.nl"
});
shops.push({
    id: 2465,
    name: "Trip2Go.nl",
    domain: "trip2go.nl"
});
shops.push({
    id: 2477,
    name: "Unisportstore.nl",
    domain: "unisportstore.nl"
});
shops.push({
    id: 2446,
    name: "Verandervanprovider.nl",
    domain: "verandervanprovider.nl"
});
shops.push({
    id: 2478,
    name: "Viata.nl",
    domain: "viata.nl"
});
shops.push({
    id: 2504,
    name: "Vitamins.nl",
    domain: "vitamins.nl"
});
shops.push({
    id: 2462,
    name: "Vitstore.com",
    domain: "vitstore.com"
});
shops.push({
    id: 1963,
    name: "Voetbalfanwinkel.nl",
    domain: "voetbalfanwinkel.nl"
});
shops.push({
    id: 1962,
    name: "Voetbalreizen.com",
    domain: "voetbalreizen.com"
});
shops.push({
    id: 51,
    name: "Voetbalshop.nl",
    domain: "voetbalshop.nl"
});
shops.push({
    id: 2472,
    name: "Wasmachine.nl",
    domain: "wasmachine.nl"
});
shops.push({
    id: 2458,
    name: "Winetraining+Online",
    domain: "winetraining-online.com"
});
shops.push({
    id: 2489,
    name: "Xmasdeco.nl",
    domain: "xmasdeco.nl"
});
shops.push({
    id: 2449,
    name: "Xvida",
    domain: "xvida.nl"
});
shops.push({
    id: 55,
    name: "Yves+Rocher",
    domain: "yves-rocher.nl"
});
shops.push({
    id: 2156,
    name: "Zorgverzekeringvergelijker",
    domain: "zorgverzekeringvergelijker.nl"
});
shops.push({
    id: 2088,
    name: "Met+jou",
    domain: "metjou.nl"
});
shops.push({
    id: 11,
    name: "Bodyshop",
    domain: "thebodyshop.nl"
});
shops.push({
    id: 1995,
    name: "BoumanOnline",
    domain: "boumanonline.nl"
});
shops.push({
    id: 2236,
    name: "DealeXtreme",
    domain: "dx.com"
});
shops.push({
    id: 2171,
    name: "Paleo",
    domain: "paleo.nl"
});
shops.push({
    id: 2175,
    name: "Paleo",
    domain: "paleo.nl"
});
shops.push({
    id: 2206,
    name: "Turbo+SEO",
    domain: "zoekmachine-optimalisatie-boek.nl"
});
shops.push({
    id: 2159,
    name: "Spartoo",
    domain: "spartoo.nl"
});
shops.push({
    id: 2113,
    name: "Sarenza",
    domain: "sarenza.nl"
});
shops.push({
    id: 2158,
    name: "Media Markt",
    domain: "mediamarkt.nl"
});
shops.push({
    id: 2523,
    name: "Vliegtickets.nl",
    domain: "Vliegtickets.nl"
});
shops.push({
    id: 2696,
    name: "Rentalcars.com",
    domain: "Rentalcars.com"
});
